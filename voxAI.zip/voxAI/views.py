from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.template import loader
from .models import AudioPrediction
import joblib
import librosa
import numpy as np
from tensorflow import keras



def voxAI(request):
    if request.method == 'POST' and request.FILES['audio_file']:
        audio_file = request.FILES['audio_file']
        features_age,audio = feature_extraction(audio_file)
        features_age = np.array([features_age])

        features = extract_features(audio,22050)
       # print(x)
        # Perform the predictions using the saved models
        scaler_age = joblib.load('scaler.joblib')   
        scaler_gender = joblib.load('gender_scaler.joblib')
        scaler_emotion = joblib.load('scaler_emotion.joblib')


        features = scaler_emotion.transform(features.reshape(1, -1))
        features = np.expand_dims(features, axis=2) 
        age_model = joblib.load('age_model.sav')
        gender_model = joblib.load('gender_pred.sav')
        emotion_model = keras.models.load_model('model.h5')
        age_x=scaler_age.transform(features_age)
        gender_x = scaler_gender.transform(features_age)
       # emotion_model = joblib.load('emotionmodel.sav')
        prediction = emotion_model.predict(features)
        encoder = joblib.load('emo_encoder.joblib')
        emotion_label = encoder.inverse_transform(prediction)
        gender_prediction = gender_model.predict(gender_x)
        age_prediction = age_model.predict(age_x)
        emotion_prediction = emotion_label
        if gender_prediction[0] == 0:
            gender_prediction = 'Female'
        elif gender_prediction[0] == 1:
            gender_prediction = 'Other'
        else:
            gender_prediction = 'Male'
        

        age = encode_age(age_prediction)



        # Save the predictions in the database
        AudioPrediction.objects.create(
            audio_file=audio_file,
            gender_prediction=gender_prediction,
            age_prediction=age,
            emotion_prediction=emotion_prediction[0][0]
        )
        
        return redirect('prediction_result')
    
    return render(request, 'home.html')

def prediction_result(request):
    latest_prediction = AudioPrediction.objects.latest('id')
    return render(request, 'prediction_result.html', {'prediction': latest_prediction})





##################################################################


def feature_extraction(filename, sampling_rate=48000):
    features = list()
    audio, _ = librosa.load(filename, sr=sampling_rate)
    spectral_centroid = np.mean(librosa.feature.spectral_centroid(y=audio, sr=sampling_rate))
    spectral_bandwidth = np.mean(librosa.feature.spectral_bandwidth(y=audio, sr=sampling_rate))
    spectral_rolloff = np.mean(librosa.feature.spectral_rolloff(y=audio, sr=sampling_rate))
  #  features.append(gender)
    features.append(spectral_centroid)
    features.append(spectral_bandwidth)
    features.append(spectral_rolloff)
    
    mfcc = librosa.feature.mfcc(y=audio, sr=sampling_rate)
    for el in mfcc:
        features.append(np.mean(el))
    
    return features, audio


def extract_features(data, sample_rate):
    # ZCR
    result = np.array([])
    zcr = np.mean(librosa.feature.zero_crossing_rate(y=data).T, axis=0)
    result = np.hstack((result, zcr)) # stacking horizontally

    # Chroma_stft
    stft = np.abs(librosa.stft(data))
    chroma_stft = np.mean(librosa.feature.chroma_stft(S=stft, sr=sample_rate).T, axis=0)
    result = np.hstack((result, chroma_stft)) # stacking horizontally

    # MFCC
    mfcc = np.mean(librosa.feature.mfcc(y=data, sr=sample_rate).T, axis=0)
    result = np.hstack((result, mfcc)) # stacking horizontally

    # Root Mean Square Value
    rms = np.mean(librosa.feature.rms(y=data).T, axis=0)
    result = np.hstack((result, rms)) # stacking horizontally

    # MelSpectogram
    mel = np.mean(librosa.feature.melspectrogram(y=data, sr=sample_rate).T, axis=0)
    result = np.hstack((result, mel)) # stacking horizontally

    return result

def encode_age(age):
    decode = ['fifties', 'fourties', 'nineties', 'seventies', 'sixties', 'teens', 'thirties',
 'twenties']
    return decode[age[0]] 

