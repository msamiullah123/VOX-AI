from django.db import models

class AudioPrediction(models.Model):
    audio_file = models.FileField(upload_to='audio/')
    gender_prediction = models.CharField(max_length=10)
    age_prediction = models.CharField(max_length=30)
    emotion_prediction = models.CharField(max_length=20)