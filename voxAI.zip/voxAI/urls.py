from django.urls import path
from .views import voxAI, prediction_result

urlpatterns = [
    path('', voxAI, name='voxAI'),
    path('prediction_result/', prediction_result, name='prediction_result'),
]
